from django.apps import AppConfig


class PjarticlesConfig(AppConfig):
    name = 'pjarticles'
